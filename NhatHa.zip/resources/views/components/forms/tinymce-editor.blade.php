<div>
   <textarea class="editor">Hello, World!</textarea>
</div>
