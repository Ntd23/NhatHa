<?php

return [
    App\Providers\AppServiceProvider::class,
		// Darryldecode\Cart\Facades\CartFacade::class
];
