<header class="header header-8">
  <div class="header-top">
    <div class="container">
      <div class="header-right">
        <ul class="top-menu">
          <li>
            <a href="#">Links</a>
            <ul>
              <li><a href="tel:<?php echo e($getSystemSettingApp->phone); ?>"><i class="icon-phone"></i>Gọi:
                  <?php echo e($getSystemSettingApp->phone); ?></a></li>
              <?php if(!empty(Auth::check())): ?>
                <li><a href="<?php echo e(route('front.my_wishlist')); ?>"><i class="icon-heart-o"></i>My Wishlist<span></span></a>
                </li>
              <?php else: ?>
                <li><a href="#signin-modal" data-toggle="modal"><i class="icon-heart-o"></i>My Wishlist<span></span></a>
                </li>
              <?php endif; ?>
              <li><a href="<?php echo e(route('front.contact')); ?>">Liên hệ</a></li>
              <?php if(!empty(Auth::check())): ?>
                <li><a href="<?php echo e(route('front.dashboard')); ?>"><?php echo e(Auth::user()->name); ?></a></li>
              <?php else: ?>
                <li><a href="#signin-modal" data-toggle="modal"><i class="icon-user"></i>Login</a></li>
              <?php endif; ?>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="header-middle sticky-header">
    <div class="container">
      <div class="header-left">
        <button class="mobile-menu-toggler">
          <span class="sr-only">Toggle mobile menu</span>
          <i class="icon-bars"></i>
        </button>
        <a href="<?php echo e(route('front.home')); ?>" class="logo">
          <img src="<?php echo e(url($getSystemSettingApp->getLogo())); ?>" alt="Molla Logo" style="width: 100px;height: auto;">
        </a>
      </div>

      <nav class="main-nav" style="margin-right: 20rem;">
        <ul class="menu sf-arrows ml-5">
          <li class="megamenu-container active">
            <a href="<?php echo e(route('front.home')); ?>"
              style="font-size: medium; font-weight: bolder; padding-top: 6.25rem; color: white;">Trang chủ</a>
          </li>
          <li style="padding-bottom: 25px;">
            <?php
              $getCategoryHeader = \App\Models\Category::getRecordMenu();
            ?>
            <?php $__currentLoopData = $getCategoryHeader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value_h_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="nav-item dropdown position-relative d-inline-block">
                <a href="<?php echo e(route('front.category', $value_h_c->slug)); ?>" class="nav-link px-3 text-uppercase"
                  style="padding-top: 6.25rem; font-weight: 700; font-size: medium; color: white;">
                  <?php echo e($value_h_c->name); ?>

                </a>
                <div class="custom-dropdown position-absolute">
                  <ul class="list-unstyled">
                    <?php $__currentLoopData = $value_h_c->getSubCategory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value_h_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <a href="<?php echo e(route('front.category', [$value_h_c->slug, $value_h_sub->slug])); ?>"
                          class="dropdown-item py-2 px-3">
                          <?php echo e($value_h_sub->name); ?>

                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </li>
          <li style="padding-bottom: 25px;">
            <?php
              $pages = \App\Models\Page::getRecordExceptHome();
            ?>
            <div class="nav-item dropdown position-relative d-inline-block">
              <a href="#" class="nav-link px-3 text-uppercase"
                style="padding-top: 6.25rem; font-weight: 700; font-size: medium; color: white;">
                Trang
              </a>
              <div class="custom-dropdown position-absolute">
                <ul class="list-unstyled">
                  <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <a href="<?php echo e(url($page->slug)); ?>" class="dropdown-item py-2 px-3">
                        <?php echo e($page->title); ?>

                      </a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </nav>

      <div class="header-right">
        <div class="header-search">
          <a href="#" class="search-toggle" role="button"><i class="icon-search"></i></a>
          <form action="<?php echo e(route('front.search')); ?>" method="get">
            <div class="header-search-wrapper">
              <label for="q" class="sr-only">Search</label>
              <input type="search" class="form-control" name="q"
                value="<?php echo e(!empty(Request::get('q')) ? Request::get('q') : ''); ?>" id="q"
                placeholder="Tìm kiếm..." required>
            </div>
          </form>
        </div>
        <div class="dropdown cart-dropdown" style="padding-top: 18px;">
          <a href="#" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false" data-display="static" style="display: block !important; color: white;">
            <i class="icon-shopping-cart" style="position: absolute; top: -12px; right: 0;"></i>
            <span class="cart-count"
              style="position: absolute; top: -20px; right: -5px;"><?php echo e(Cart::getContent()->count()); ?></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right">
            <div class="dropdown-cart-products">
              <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header_cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $getCartProduct = App\Models\Product::getSingle($header_cart->id);
                ?>
                <?php if(!empty($getCartProduct)): ?>
                  <?php
                    $getProductImage = $getCartProduct->getImageSingle($getCartProduct->id);
                  ?>
                  <div class="product">
                    <div class="product-cart-details">
                      <h4 class="product-title">
                        <a href="<?php echo e($getCartProduct->slug); ?>"><?php echo e($getCartProduct->title); ?></a>
                      </h4>
                      <span class="cart-product-info">
                        <span class="cart-product-qty"><?php echo e($header_cart->quantity); ?></span>
                        x <?php echo number_format((float)($header_cart->price), 0, '.', ',') . ' VND'; ?>
                      </span>
                    </div>
                    <figure class="product-image-container">
                      <a href="<?php echo e($getCartProduct->slug); ?>" class="product-image">
                        <img src="<?php echo e($getProductImage->getLogo()); ?>" alt="product">
                      </a>
                    </figure>
                    <a href="<?php echo e(route('front.cart_delete', $header_cart->id)); ?>" class="btn-remove"
                      title="Xóa sản phẩm"><i class="icon-close"></i></a>
                  </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="dropdown-cart-total">
              <span>Tổng</span>
              <span class="cart-total-price"><?php echo number_format((float)(Cart::getSubTotal()), 0, '.', ',') . ' VND'; ?></span>
            </div>
            <div class="dropdown-cart-action">
              <a href="<?php echo e(route('front.cart')); ?>" class="btn btn-primary">Xem giỏ hàng</a>
              <a href="<?php echo e(route('front.checkout')); ?>" class="btn btn-outline-primary-2"><span>Thanh toán</span><i
                  class="icon-long-arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<div class="alert alert-success position-fixed"
  style="top: 20px; right: -300px; width: 300px; transition: all 0.5s ease;" role="alert" id="messageAlert">
  <?php echo $__env->make('layout._message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/layout/header.blade.php ENDPATH**/ ?>