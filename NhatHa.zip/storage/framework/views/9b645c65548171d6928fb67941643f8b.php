<?php
  $getSettingHeader = App\Models\SystemSetting::getSingle();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('admin.layout.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
  <div class="main-wrapper">
    <?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('admin.layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


  </div>
  <div class="sidebar-overlay" data-reff=""></div>
  <?php echo $__env->make('admin.layout.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
	<?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>