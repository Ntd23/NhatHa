<?php $__env->startComponent('mail::message'); ?>
  <?php
    $getSetting = App\Models\SystemSetting::getSingle();
  ?>
	Từ, <?php echo e($getSetting->website_name); ?>

  Xin chào, <b><?php echo e($user->name); ?></b>
  <p>Click để kích hoạt tài khoản.</p>
  <p>
    <?php $__env->startComponent('mail::button', ['url' => route('active_email',base64_encode($user->id))]); ?>
      Xác nhận
    <?php echo $__env->renderComponent(); ?>
  </p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/email/register.blade.php ENDPATH**/ ?>