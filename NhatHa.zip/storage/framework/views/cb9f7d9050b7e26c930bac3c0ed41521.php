<?php $__env->startSection('content'); ?>
  <main class="main ">
    <div class="container">
      <div class="intro-slider-container slider-container-ratio mb-2">
        <div class="intro-slider owl-carousel owl-simple owl-light owl-nav-inside" data-toggle="owl"
          data-owl-options='{"nav": false}'>
          <?php $__currentLoopData = $getSlider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($slider->getImage())): ?>
              <div class="intro-slide">
                <figure class="slide-image">
                  <picture>
                    <source media="(max-width: 480px)" srcset="<?php echo e($slider->getImage()); ?>">
                    <img src="<?php echo e($slider->getImage()); ?>" alt="<?php echo e($slider->title); ?>">
                  </picture>
                </figure><!-- End .slide-image -->
                <div class="intro-content">
                  <h3 class="h2 font-weight-bolder text-danger"><?php echo $slider->title; ?></h3><!-- End .h3 intro-subtitle -->
                  <?php if(!empty($slider->button_name) && !empty($slider->button_link)): ?>
                    <a href="<?php echo e($slider->button_link); ?>" class="btn btn-white-primary btn-round">
                      <span><?php echo e($slider->button_name); ?></span>
                      <i class="icon-long-arrow-right"></i>
                    </a>
                  <?php endif; ?>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div><!-- End .intro-slider owl-carousel owl-simple -->
        <span class="slider-loader"></span><!-- End .slider-loader -->
      </div><!-- End .intro-slider-container -->
    </div>

    <div class="icon-boxes-container icon-boxes-separator bg-transparent">
      <div class="container">
        <div class="row">
          <?php if(!empty($getHomeSetting->payment_delivery_title)): ?>
            <div class="col-sm-6 col-lg-3">
              <div class="icon-box icon-box-side">
                <?php if(!empty($getHomeSetting->getPaymentDeliveryImage())): ?>
                  <span class="icon-box-icon text-primary">
                    <img src="<?php echo e($getHomeSetting->getPaymentDeliveryImage()); ?>" style="width: 50px; height: 50px;" class="rounded-circle" alt="">
                  </span>
                <?php endif; ?>
                <div class="icon-box-content">
                  <h3 class="icon-box-title"><?php echo e($getHomeSetting->payment_delivery_title); ?></h3>
                  <p><?php echo e($getHomeSetting->payment_delivery_description); ?></p>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php if(!empty($getHomeSetting->refund_title)): ?>
            <div class="col-sm-6 col-lg-3">
              <div class="icon-box icon-box-side">
                <?php if(!empty($getHomeSetting->getRefundImage())): ?>
                  <span class="icon-box-icon text-primary">
                    <img src="<?php echo e($getHomeSetting->getRefundImage()); ?>" style="width: 50px; height: 50px;" class="rounded-circle" alt="">
                  </span>
                <?php endif; ?>
                <div class="icon-box-content">
                  <h3 class="icon-box-title"><?php echo e($getHomeSetting->refund_title); ?></h3>
                  <p><?php echo e($getHomeSetting->refund_description); ?></p>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php if(!empty($getHomeSetting->suport_title)): ?>
            <div class="col-sm-6 col-lg-3">
              <div class="icon-box icon-box-side">
                <?php if(!empty($getHomeSetting->getSupportImage())): ?>
                  <span class="icon-box-icon text-primary">
                    <img src="<?php echo e($getHomeSetting->getSupportImage()); ?>" style="width: 50px; height: 50px;" class="rounded-circle" alt="">
                  </span>
                <?php endif; ?>
                <div class="icon-box-content">
                  <h3 class="icon-box-title"><?php echo e($getHomeSetting->suport_title); ?></h3>
                  <p><?php echo e($getHomeSetting->suport_description); ?></p>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php if(!empty($getHomeSetting->signup_title)): ?>
            <div class="col-sm-6 col-lg-3">
              <div class="icon-box icon-box-side">
                <?php if(!empty($getHomeSetting->getSignupImage())): ?>
                  <span class="icon-box-icon text-primary">
                    <img src="<?php echo e($getHomeSetting->getSignupImage()); ?>" style="width: 50px; height: 50px;" class="rounded-circle" alt="">
                  </span>
                <?php endif; ?>
                <div class="icon-box-content">
                  <h3 class="icon-box-title"><?php echo e($getHomeSetting->signup_title); ?></h3>
                  <p><?php echo e($getHomeSetting->signup_description); ?></p>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    
    <?php if(!empty($getCategory->count())): ?>
      <div class="container">
        <h2 class="title-lg mb-2 text-center">
          <?php echo e(!empty($getHomeSetting->shop_category_title) ? $getHomeSetting->shop_category_title : 'Mua sắm theo danh mục'); ?>

        </h2>
        <div class="row justify-content-center">

          <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($category->getImage())): ?>
              <div class="col-sm-5 col-md-3">
                <div class="banner banner-cat">
                  <a href="<?php echo e(route('front.category', $category->slug)); ?>">
                    <img src="<?php echo e($category->getImage()); ?>" alt="<?php echo e($category->name); ?>">
                  </a>
                  <div class="banner-content banner-content-overlay text-center">
                    <h3 class="banner-title font-weight-normal"><a
                        href="<?php echo e(route('front.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></h3>
                    <h4 class="banner-subtitle"><?php echo e($category->getProduct()->count()); ?> sản phẩm</h4>
                    <?php if(!empty($category->button_name)): ?>
                      <a href="<?php echo e(route('front.category', $category->slug)); ?>"
                        class="banner-link"><?php echo e($category->button_name); ?></a>
                    <?php endif; ?>
                  </div><!-- End .banner-content -->
                </div><!-- End .banner -->
              </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endif; ?>
    <div class="mb-4"></div><!-- End .mb-4 -->
    <div class="container">
      <div class="heading heading-center mb-3">
        <h2 class="title-lg mb-2">
          <?php echo e(!empty($getHomeSetting->trendy_product_title) ? $getHomeSetting->trendy_product_title : 'Sản phẩm thịnh hành'); ?>


        </h2>
        <ul class="nav nav-pills justify-content-center" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="top-all-link" data-toggle="tab" href="#top-all-tab" role="tab"
              aria-controls="top-all-tab" aria-selected="true">All</a>
          </li>
          <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
              <a class="nav-link getCategoryProduct" id="top-<?php echo e($category->slug); ?>-link" data-toggle="tab"
                data-val="<?php echo e($category->id); ?>" href="#top-<?php echo e($category->slug); ?>-tab" role="tab"
                aria-controls="top-<?php echo e($category->slug); ?>-tab" aria-selected="false"><?php echo e($category->name); ?></a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="tab-content">
        <div class="tab-pane p-0 fade show active" id="top-all-tab" role="tabpanel" aria-labelledby="top-all-link">
          <div class="products">
            <?php
              $is_home = 1;
            ?>
            <?php echo $__env->make('product._list', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          </div><!-- End .products -->
          <div class="more-container text-center mt-5">
            <a href="<?php echo e(route('front.search')); ?>" class="btn btn-outline-lightgray btn-more btn-round"><span>Xem
                thêm</span><i class="icon-long-arrow-right"></i></a>
          </div>
        </div>
        <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="tab-pane p-0 fade getCategoryProduct<?php echo e($category->id); ?>" id="top-<?php echo e($category->slug); ?>-tab"
            role="tabpanel" aria-labelledby="top-<?php echo e($category->slug); ?>-link">
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    


    <div class="mb-5"></div><!-- End .mb5 -->
    <?php if(!empty($getBlog->count())): ?>
      <div class="blog-posts">
        <div class="container">
          <h2 class="title-lg text-center mb-4">Bài viết từ chúng tôi</h2><!-- End .title-lg text-center -->

          <div class="owl-carousel owl-simple mb-4" data-toggle="owl"
            data-owl-options='{
                            "nav": false,
                            "dots": true,
                            "items": 3,
                            "margin": 20,
                            "loop": false,
                            "responsive": {
                                "0": {
                                    "items":1
                                },
                                "520": {
                                    "items":2
                                },
                                "768": {
                                    "items":3
                                },
                                "992": {
                                    "items":4
                                }
                            }
                        }'>
            <?php $__currentLoopData = $getBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <article class="entry">
                <figure class="entry-media">
                  <a href="<?php echo e(route('front.blog_detail', $blog->slug)); ?>">
                    <img src="<?php echo e($blog->getImage()); ?>" alt="<?php echo e($blog->title); ?>">
                  </a>
                </figure>
                <div class="entry-body text-center">
                  <div class="entry-meta">
                    <a href="#"><?php echo e(date('M d, Y', strtotime($blog->created_at))); ?></a>, 0 bình luận
                  </div>
                  <h3 class="entry-title">
                    <a href="<?php echo e(route('front.blog_detail', $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                  </h3>
                  <div class="entry-content">
                    <p><?php echo substr($blog->short_description, 0, 25) . '...'; ?></p>
                    <a href="<?php echo e(route('front.blog_detail', $blog->slug)); ?>" class="read-more">Đọc thêm</a>
                  </div>
                </div>
              </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="more-container text-center mt-1">
            <a href="<?php echo e(route('front.blog')); ?>" class="btn btn-outline-lightgray btn-more btn-round"><span>Xem
                thêm</span><i class="icon-long-arrow-right"></i></a>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
    $('body').delegate('.getCategoryProduct', 'click', function() {
      var category_id = $(this).attr('data-val')
      $.ajax({
        url: '<?php echo e(route('front.recent_arrival_category_product')); ?>',
        type: 'POST',
        data: {
          '_token': '<?php echo e(csrf_token()); ?>',
          category_id: category_id
        },
        dataType: 'json',
        success: function(response) {
          $('.getCategoryProduct' + category_id).html(response.success)
        }
      })
    })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/layout/main.blade.php ENDPATH**/ ?>