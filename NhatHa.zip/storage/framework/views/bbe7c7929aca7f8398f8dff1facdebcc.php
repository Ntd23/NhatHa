<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/nouislider/nouislider.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
      <div class="container">
        <?php if(!empty($getSubCategory)): ?>
          <h1 class="page-title"><?php echo e($getSubCategory->name); ?></h1>
        <?php elseif(!empty($getCategory)): ?>
          <h1 class="page-title"><?php echo e($getCategory->name); ?></h1>
        <?php else: ?>
          <h1 class="page-title">Tìm kiếm: <?php echo e(Request::get('q')); ?></h1>
        <?php endif; ?>
      </div>
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav mb-2">
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Trang chủ</a></li>
          <?php if(!empty($getSubCategory)): ?>
            <li class="breadcrumb-item active" aria-current="page"><a
                href="<?php echo e(route('front.category', $getCategory->slug)); ?>"><?php echo e($getCategory->name); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($getSubCategory->name); ?></li>
          <?php elseif(!empty($getCategory)): ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($getCategory->name); ?></li>
          <?php endif; ?>
        </ol>
      </div>
    </nav>
    <div class="page-content">
      <div class="container">
        <div class="row">
          <div class="col-lg-9">
            <div class="toolbox">
              <div class="toolbox-left">
                <div class="toolbox-info">
                  Hiển thị <span> <?php echo e($getProduct->perPage()); ?>/<?php echo e($getProduct->total()); ?></span> sản phẩm
                </div>
              </div>
            </div>
            <div id="getProductAjax">
              <?php echo $__env->make('product._list', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="text-center">
              <a href="javascript:;" <?php if(empty($page)): ?> style="display: none;" <?php endif; ?>
                class="btn btn-primary LoadMore" data-page="<?php echo e($page); ?>">Xem thêm</a>
            </div>
          </div>
          <aside class="col-lg-3 order-lg-first">
            <form id="FilterForm" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="q" value="<?php echo e(!empty(Request::get('q')) ? Request::get('q') : ''); ?>">
              <input type="hidden" name="old_category_id" value="<?php echo e(!empty($getCategory) ? $getCategory->id : ''); ?>">
              <input type="hidden" name="old_sub_category_id"
                value="<?php echo e(!empty($getSubCategory) ? $getSubCategory->id : ''); ?>">
              <input type="hidden" name="sub_category_id" id="get_sub_category_id">
              <input type="hidden" name="brand_id" id="get_brand_id">
              <input type="hidden" name="size_id" id="get_size_id">
              <input type="hidden" name="start_price" id="get_start_price">
              <input type="hidden" name="end_price" id="get_end_price">
              <input type="hidden" name="sort_by_id" id="get_sort_by_id">
            </form>
            <div class="sidebar sidebar-shop">
              <div class="widget widget-clean">
                <label>Lọc sản phẩm:</label>
                <a href="" class="sidebar-filter-clear">Hủy bỏ</a>
              </div>
              <?php if(!empty($getSubCategoryFilter)): ?>
                <div class="widget widget-collapsible">
                  <h3 class="widget-title">
                    <a data-toggle="collapse" href="#widget-1" role="button" aria-expanded="true"
                      aria-controls="widget-1">
                      Danh mục
                    </a>
                  </h3>
                  <div class="collapse show" id="widget-1">
                    <div class="widget-body">
                      <div class="filter-items filter-items-count">
                        <?php $__currentLoopData = $getSubCategoryFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="filter-item">
                            <div class="custom-control custom-checkbox">
                              <input type="checkbox" class="custom-control-input ChangeCategory"
                                value="<?php echo e($f_category->id); ?>" id="cat-<?php echo e($f_category->id); ?>">
                              <label class="custom-control-label"
                                for="cat-<?php echo e($f_category->id); ?>"><?php echo e($f_category->name); ?></label>
                            </div>
                            <span class="item-count"><?php echo e($f_category->TotalProduct()); ?></span>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endif; ?>

              <div class="widget widget-collapsible">
                <h3 class="widget-title">
                  <a data-toggle="collapse" href="#widget-2" role="button" aria-expanded="true"
                    aria-controls="widget-2">
                    Kích cỡ
                  </a>
                </h3>

                <div class="collapse show" id="widget-2">
                  <div class="widget-body">
                    <div class="filter-items">
                      <?php $__currentLoopData = $getSize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="filter-item">
                          <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input ChangeSize" value="<?php echo e($f_size->id); ?>"
                              id="size-<?php echo e($f_size->id); ?>">
                            <label class="custom-control-label"
                              for="size-<?php echo e($f_size->id); ?>"><?php echo e($f_size->name); ?></label>
                          </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </div>
              </div>

              <div class="widget widget-collapsible">
                <h3 class="widget-title">
                  <a data-toggle="collapse" href="#widget-4" role="button" aria-expanded="true"
                    aria-controls="widget-4">
                    Thương hiệu
                  </a>
                </h3>
                <div class="collapse show" id="widget-4">
                  <div class="widget-body">
                    <div class="filter-items">
                      <?php $__currentLoopData = $getBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="filter-item">
                          <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input ChangeBrand"
                              value="<?php echo e($f_brand->id); ?>" id="brand-<?php echo e($f_brand->id); ?>">
                            <label class="custom-control-label"
                              for="brand-<?php echo e($f_brand->id); ?>"><?php echo e($f_brand->name); ?></label>
                          </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="widget widget-collapsible">
                <h3 class="widget-title">
                  <a data-toggle="collapse" href="#widget-5" role="button" aria-expanded="true"
                    aria-controls="widget-5">
                    Giá tiền
                  </a>
                </h3>
                <div class="collapse show" id="widget-5">
                  <div class="widget-body">
                    <div class="filter-price">
                      <div class="filter-price-text">
                        <span id="filter-price-range"></span>
                      </div>
                      <div id="price-slider"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
    $('.ChangeCategory').change(function() {
      let ids = '';
      $('.ChangeCategory').each(function() {
        if (this.checked) {
          let id = $(this).val()
          ids += id + ','
        }
      })
      $('#get_sub_category_id').val(ids)
      FilterForm()
    })
    $('.ChangeBrand').change(function() {
      let ids = '';
      $('.ChangeBrand').each(function() {
        if (this.checked) {
          let id = $(this).val()
          ids += id + ','
        }
      })
      $('#get_brand_id').val(ids)
      FilterForm()
    })
    $('.ChangeSize').change(function() {
      let ids = '';
      $('.ChangeSize').each(function() {
        if (this.checked) {
          let id = $(this).val()
          ids += id + ','
        }
      })
      $('#get_size_id').val(ids)
      FilterForm()
    })
		$('.ChangeSortBy').change(function() {
			let id= $(this).val()
			$('#get_sort_by_id').val(id)
			FilterForm()
		})
    //load more products
    $('body').delegate('.LoadMore', 'click', function() {
      let page = $(this).attr('data-page');
      $('.LoadMore').html('Vui lòng chờ trong giây lát...')
      if (xhr && xhr.readyState != 4) {
        xhr.abort()
      }
      xhr = $.ajax({
        type: 'POST',
        url: "<?php echo e(route('front.filter_product')); ?>?page=" + page,
        data: $('#FilterForm').serialize(),
        dataType: 'json',
        success: function(data) {
          $('#getProductAjax').append(data.success)
          $('.LoadMore').attr('data-page', data.page)
          if (data.page == 0) $('.LoadMore').hide()
          else $('.LoadMore').show()
        },
        error: function() {
          alert(1)
        }
      })
    })
    //slider filter price
    var i = 0;
    if (typeof noUiSlider === 'object') {
      var priceSlider = document.getElementById('price-slider');
      var mininit = 200000;
      var maxinit = 5000000;
      noUiSlider.create(priceSlider, {
        start: [mininit, maxinit],
        connect: true,
        step: 1,
        margin: 200,
        range: {
          'min': mininit,
          'max': maxinit
        },
        tooltips: true,
        format: wNumb({
          decimals: 0,
          thousand: ',',
          suffix: 'VND',
        })
      });
      priceSlider.noUiSlider.on('update', function(values, handle) {
        var start_price = values[0]
        var end_price = values[1]
        $('#get_start_price').val(start_price)
        $('#get_end_price').val(end_price)
        $('#filter-price-range').text(values.join(' - '));
        FilterForm()
        if (i == 0 || i == 1) {
          i++;
        } else {
          FilterForm()
        }
      });
    }
    var xhr;

    function FilterForm() {
      if (xhr && xhr.readyState != 4) {
        xhr.abort();
      }
      xhr = $.ajax({
        type: 'POST',
        url: "<?php echo e(route('front.filter_product')); ?>",
        data: $('#FilterForm').serialize(),
        dataType: 'json',
        success: function(data) {
          $('#getProductAjax').html(data.success)
          $('.LoadMore').attr('data-page', data.page)
          $('.LoadMore').html('Vui lòng chờ trong giây lát...')
          if (data.page == 0) $('.LoadMore').hide()
          else $('.LoadMore').show()
        },
        error: function() {

        }
      })
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/product/list.blade.php ENDPATH**/ ?>