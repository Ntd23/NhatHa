<?php $__env->startSection('style'); ?>
  <style>
    .box-btn {
      height: 110px;
      text-align: center;
      border-radius: 5px;
      box-shadow: 0 0 1px rgba(0, 0, 0, .125), 0 1px 3px rgba(0, 0, 0, .2);
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
      <div class="container">
        <h1 class="page-title">Theo dõi đơn hàng</h1>
      </div>
    </div>

    <div class="page-content">
      <div class="dashboard">
        <div class="container">
          <hr>
          <hr>
          <div class="row">
            <?php echo $__env->make('user._sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-md-9 col-lg-10">
              <div class="tab-content">
                <?php echo $__env->make('layout._message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div>
                  <div class="form-group">
                    <label>Mã đặt hàng : <span class="font-weight-normal"><?php echo e($getRecord->order_number); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Họ tên : <span
                        class="font-weight-normal"><?php echo e($getRecord->last_name . ' ' . $getRecord->first_name); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Công ty : <span class="font-weight-normal"><?php echo e($getRecord->company_name); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Quốc gia : <span class="font-weight-normal"><?php echo e($getRecord->country); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Địa chỉ : <span
                        class="font-weight-normal"><?php echo e($getRecord->address_one . ' , ' . $getRecord->address_two); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Thành phố : <span class="font-weight-normal"><?php echo e($getRecord->city); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Quận/Huyện : <span class="font-weight-normal"><?php echo e($getRecord->district); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Mã bưu điện : <span class="font-weight-normal"><?php echo e($getRecord->postcode); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Điện thoại : <span class="font-weight-normal"><?php echo e($getRecord->phone); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Mã giảm giá : <span class="font-weight-normal"><?php echo e($getRecord->discount_code); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Đã giảm : <span class="font-weight-normal"><?php echo number_format((float)($getRecord->discount_amount), 0, '.', ',') . ' VND'; ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Giao hàng : <span
                        class="font-weight-normal"><?php echo e($getRecord->getShipping->name); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Phí giao hàng : <span class="font-weight-normal"><?php echo number_format((float)($getRecord->shipping_amount), 0, '.', ',') . ' VND'; ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Thành tiền : <span class="font-weight-normal"><?php echo number_format((float)($getRecord->total_amount), 0, '.', ',') . ' VND'; ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Phương thức thanh toán : <span
                        class="font-weight-normal"><?php echo e($getRecord->payment_method); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Ghi chú: <span class="font-weight-normal"><?php echo e($getRecord->note); ?></span></label>
                  </div>
                  <div class="form-group">
                    <label>Trạng thái : <span class="font-weight-normal">
                        <?php if($getRecord->status == 0): ?>
                          Chờ xác nhận
                        <?php elseif($getRecord->status == 1): ?>
                          Chờ giao hàng
                        <?php elseif($getRecord->status == 2): ?>
                          Đã giao hàng
                        <?php elseif($getRecord->status == 3): ?>
                          Đã hoàn thành
                        <?php elseif($getRecord->status == 4): ?>
                          Đã hủy
                        <?php endif; ?>
                      </span></label>
                  </div>
                  <div class="form-group">
                    <label>Ngày đặt : <span
                        class="font-weight-normal"><?php echo e(date('d-m-Y h:i A', strtotime($getRecord->created_at))); ?></span></label>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header mt-2">
                    <h3 class="card-title">Thông tin sản phẩm</h3>
                  </div>
                  <div class="card-body p-0" style="overflow: auto;">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Hình ảnh</th>
                          <th>Sản phẩm</th>
                          <th>Số tiền (Size)</th>
                          <th>Số lượng</th>
                          <th>Tổng</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $getRecord->getItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                            $getProductImage = $item->getProduct->getImageSingle($item->getProduct->id);
                          ?>
                          <tr>
                            <td>
                              <img src="<?php echo e($getProductImage->getLogo()); ?>" style="width: 100px;height: 100px;">
                            </td>
                            <td>
                              <a href="<?php echo e(route('front.category', $item->getProduct->slug)); ?>" target="_blank"
                                rel="noopener noreferrer">
                                <?php echo e(substr($item->getProduct->title, 0, 30) . '...'); ?></a>
                              <?php if(!empty($item->size_name)): ?>
                                <br>
                                <b>Size(Loại):</b><?php echo e($item->size_name); ?>

                              <?php endif; ?>

                              <?php if($getRecord->status == 3): ?>
                                <?php
                                  $getReview = $item->getReview($item->getProduct->id, $getRecord->id);
                                ?>
                                <?php if(!empty($getReview)): ?>
                                  Đánh giá: <?php echo e(' '. $getReview->rating); ?> <br />
                                  <b>Ý kiến: </b> <?php echo e($getReview->review); ?>

                                <?php else: ?>
                                  <button class="btn btn-outline-danger MakeReview" id="<?php echo e($item->getProduct->id); ?>"
                                    data-order=<?php echo e($getRecord->id); ?>>Đánh giá</button>
                                <?php endif; ?>
                              <?php endif; ?>
                            </td>
                            <td><?php echo number_format((float)($item->size_amount), 0, '.', ',') . ' VND'; ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo number_format((float)($item->total_price), 0, '.', ',') . ' VND'; ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div><!-- End .col-lg-9 -->
          </div><!-- End .row -->
        </div><!-- End .container -->
      </div><!-- End .dashboard -->
    </div><!-- End .page-content -->
  </main>
<?php $__env->stopSection(); ?>


<div class="modal fade" id="MakeReviewModal" tabindex="-1" role="dialog" aria-labelledby="MakeReviewModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="MakeReviewModalLabel">Đánh giá</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('front.submit_review')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="product_id" id="getProductId" required>
        <input type="hidden" name="order_id" id="getOrderId" required>
        <div class="modal-body p-5">
          <div class="form-group mb-3">
            <select name="rating" class="form-control" required>
              <option value="">Chọn *</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
            </select>
          </div>
          <div class="form-group">
            <label for="">Đánh giá *</label>
            <textarea class="form-control" name="review" required></textarea>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
            <button type="submit" class="btn btn-primary">Gửi</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->startSection('script'); ?>
<script>
	$('body').delegate('.MakeReview','click', function(){
		var product_id= $(this).attr('id')
		var order_id= $(this).attr('data-order')
		$('#getProductId').val(product_id)
		$('#getOrderId').val(order_id)
		$('#MakeReviewModal').modal('show')
	})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/user/order_detail.blade.php ENDPATH**/ ?>