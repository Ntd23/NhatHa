<?php $__env->startSection('content'); ?>
  <div class="page-wrapper">
    <div class="content">
      <div class="row">
        <div class="col-sm-12">
          <h4 class="page-title"><?php echo e($header_title); ?></h4>
        </div>
      </div>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
      <?php echo $__env->make('admin.layout.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="row">
        <div class="col-lg-12">
          <form action="<?php echo e(route('admin.update_smtp_setting')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="card-box">
              <h4 class="card-title">SMTP</h4>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Website name</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="name" value="<?php echo e($getRecord->name); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail mailer</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_mailer" value="<?php echo e($getRecord->mail_mailer); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail host</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_host" value="<?php echo e($getRecord->mail_host); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail port</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_port" value="<?php echo e($getRecord->mail_port); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail username</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_username" value="<?php echo e($getRecord->mail_username); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail password</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_password" value="<?php echo e($getRecord->mail_password); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail encryption</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_encryption" value="<?php echo e($getRecord->mail_encryption); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Mail from address</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="mail_from_address" value="<?php echo e($getRecord->mail_from_address); ?>">
                </div>
              </div>
            </div>
            <div class="m-t-20 text-center">
              <button class="btn btn-primary submit-btn">Update</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/admin/setting/smtp_setting.blade.php ENDPATH**/ ?>