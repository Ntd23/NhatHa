<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
      <div class="container">
        <h1 class="page-title">Thông báo</h1>
      </div>
    </div>
    <div class="page-content">
      <div class="dashboard">
        <div class="container">
          <hr>
          <hr>
          <div class="row">
            <?php echo $__env->make('user._sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-md-9 col-lg-10">
              <div class="tab-content">
                <table class="table table-striped">
                  <tbody>
                    <?php $__currentLoopData = $getRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="p-3">
                          <a href="<?php echo e($value->url); ?>?noti_id=<?php echo e($value->id); ?>"
                            style="color: #000; <?php echo e(empty($value->is_read) ? 'font-weight:bold' : ''); ?>">
                            <?php echo e($value->message); ?>

                          </a>
                          <div><small>
                              <?php echo e(date('d-m-Y h:i A', strtotime($value->created_at))); ?>

                            </small></div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <div style="padding: 10px; float: right;">
                  <?php echo $getRecord->appends(Illuminate\Support\Facades\Request::except('pages'))->links(); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/user/notification.blade.php ENDPATH**/ ?>