<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
      <div class="container">
        <h1 class="page-title"><?php echo e($meta_title); ?></h1>
      </div>
    </div><!-- End .page-header -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Trang chủ</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e($meta_title); ?></li>
        </ol>
      </div>
    </nav><!-- End .breadcrumb-nav -->

    <div class="page-content">
      <div class="cart">
        <div class="container">
          <?php echo $__env->make('layout._message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <?php if(!empty(Cart::getContent()->count())): ?>
            <div class="row">
              <div class="col-lg-9">
                <form action="<?php echo e(route('front.update_cart')); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <table class="table table-cart table-mobile">
                    <thead>
                      <tr>
                        <th>Sản phẩm</th>
                        <th>Giá tiền</th>
                        <th>Số lượng</th>
                        <th>Tổng</th>
                        <th></th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $getCartProduct = App\Models\Product::getSingle($cart->id);
                        ?>
                        <?php if(!empty($getCartProduct)): ?>
                          <?php
                            $getProductImage = $getCartProduct->getImageSingle($getCartProduct->id);
                          ?>
                          <tr>
                            <td class="product-col">
                              <div class="product">
                                <figure class="product-media">
                                  <a href="<?php echo e($getCartProduct->slug); ?>">
                                    <img src="<?php echo e($getProductImage->getLogo()); ?>" alt="<?php echo e($getCartProduct->name); ?>">
                                  </a>
                                </figure>
                                <h3 class="product-title">
                                  <a href="<?php echo e($getCartProduct->slug); ?>"
                                    class="mb-1 d-block"><?php echo e($getCartProduct->title); ?></a>
                                  <?php
                                    $size_id = $cart->attributes->size_id;
                                  ?>
                                  <?php if(!empty($size_id)): ?>
                                    <?php
                                      $getSize = App\Models\ProductSize::getSingle($size_id);
                                    ?>
                                    <div><b>Size:</b><?php echo e($getSize->name); ?> <?php echo number_format((float)($getSize->price), 0, '.', ',') . ' VND'; ?></div>
                                  <?php endif; ?>
                                </h3>
                              </div>
                            </td>
                            <td class="price-col"><?php echo number_format((float)($cart->price), 0, '.', ',') . ' VND'; ?></td>
                            <td class="quantity-col">
                              <div class="cart-product-quantity">
                                <input type="number" class="form-control" name="cart[<?php echo e($key); ?>][qty]"
                                  value="<?php echo e($cart->quantity); ?>" min="1" max="10" step="1"
                                  data-decimals="0" required>
                              </div>
                              <input type="hidden" value="<?php echo e($cart->id); ?>" name="cart[<?php echo e($key); ?>][id]">
                            </td>
                            <td class="total-col"><?php echo number_format((float)($cart->price * $cart->quantity), 0, '.', ',') . ' VND'; ?></td>
                            <td class="remove-col"><a href="<?php echo e(route('front.cart_delete', $cart->id)); ?>"
                                class="btn-remove"><i class="icon-close"></i></a></td>
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <button type="submit" class="btn btn-outline-dark-2 float-right">
									<span class="text-uppercase">cập nhật giỏ hàng</span><i class="icon-refresh"></i></button>
                </form>
              </div>
              <aside class="col-lg-3">
                <div class="summary summary-cart">
                  <h3 class="summary-title">Cần thanh toán:</h3>
                  <table class="table table-summary">
                    <tbody>
                      <tr class="summary-subtotal">
                        <td>Tổng:</td>
                        <td><?php echo number_format((float)(Cart::getSubTotal()), 0, '.', ',') . ' VND'; ?></td>
                      </tr>
                    </tbody>
                  </table>
                  <a href="<?php echo e(route('front.checkout')); ?>"
                    class="btn btn-outline-primary-2 btn-order btn-block text-uppercase">xử lý thanh toán</a>
                </div>
                <a href="<?php echo e(route('front.home')); ?>"
                  class="btn btn-outline-dark-2 btn-block mb-3 text-uppercase"><span>tiếp tục mua hàng</span><i
                    class="icon-refresh"></i></a>
              </aside>
            </div>

        </div>
      <?php else: ?>
        <p>Không có sản phẩm nào trong giỏ hàng</p>
        <?php endif; ?>
      </div>
    </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/payment/cart.blade.php ENDPATH**/ ?>