<?php $__env->startSection('style'); ?>
  <style>
    .box-btn {
      height: 110px;
      text-align: center;
      border-radius: 5px;
      box-shadow: 0 0 1px rgba(0, 0, 0, .125), 0 1px 3px rgba(0, 0, 0, .2);
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
      <div class="container">
        <h1 class="page-title">Đơn hàng của tôi</h1>
      </div>
    </div>

    <div class="page-content">
      <div class="dashboard">
        <div class="container">
          <hr>
          <hr>
          <div class="row">
            <?php echo $__env->make('user._sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-md-9 col-lg-10">
              <div class="tab-content">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Mã đơn hàng</th>
                      <th>Số tiền thanh toán</th>
                      <th>Phương thức thanh toán</th>
                      <th>Trạng thái</th>
                      <th>Ngày đặt</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $getOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
                      <td><?php echo e($value->order_number); ?></td>
                      <td><?php echo number_format((float)($value->total_amount), 0, '.', ',') . ' VND'; ?></td>
                      <td style="text-transform: capitalize;"><?php echo e($value->payment_method); ?></td>
                      <td>
                        <?php if($value->status == 0): ?>
                          Chờ xác nhận
                        <?php elseif($value->status == 1): ?>
                          Chờ giao hàng
                        <?php elseif($value->status == 2): ?>
                          Đã giao hàng
                        <?php elseif($value->status == 3): ?>
                          Đã hoàn thành
                        <?php elseif($value->status == 4): ?>
                          Đã hủy
                        <?php endif; ?>
                      </td>
                      <td><?php echo e(date('d-m-Y h:i A', strtotime($value->created_at))); ?></td>
                      <td>
                        <a href="<?php echo e(route('front.order_detail',$value->id)); ?>" class="btn btn-info">Chi tiết</a>
                      </td>
											</tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div><!-- End .col-lg-9 -->
          </div><!-- End .row -->
        </div><!-- End .container -->
      </div><!-- End .dashboard -->
    </div><!-- End .page-content -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/user/order.blade.php ENDPATH**/ ?>