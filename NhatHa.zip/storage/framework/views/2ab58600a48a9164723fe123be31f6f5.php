<div class="products mb-3">
  <div class="row justify-content-start">
    <?php $__currentLoopData = $getProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $getProductImage = $value->getImageSingle($value->id);
      ?>
      <div class="col-6 <?php if(!empty($is_home)): ?> col-md-3 col-lg-3 <?php else: ?> col-md-4 col-lg-4 <?php endif; ?>">
        <div class="product product-7 text-center">
          <figure class="product-media">
            <a href="<?php echo e(route('front.category', $value->slug)); ?>">
              <?php if(!empty($getProductImage) && !empty($getProductImage->getLogo())): ?>
                <img src="<?php echo e(asset($getProductImage->getLogo())); ?>" style="width: 100%;" alt="<?php echo e($value->title); ?>"
                  class="product-image">
              <?php endif; ?>
            </a>
            <div class="product-action-vertical">
            	<?php if(!empty(Auth::check())): ?>
						<a href="javascript:;" id="<?php echo e($value->id); ?>"
							class="btn-product btn-wishlist add_to_wishlist
										add_to_wishlist<?php echo e($value->id); ?> <?php echo e(!empty($value->checkWishList($value->id)) ? 'btn-wishlist-add' : ''); ?>" title="Yêu thích"><span>Thêm vào
								yêu thích</span></a>
						<?php else: ?>
						<a href="#signin-modal" data-toggle="modal" class="btn-product btn-wishlist" title="Yêu thích"><span>Thêm
								vào yêu
								thích</span></a>
						<?php endif; ?>
            </div>
            
          </figure>
          <div class="product-body">
            <div class="product-cat">
              <a
                href="<?php echo e(route('front.category', $value->category_slug, $value->sub_category_slug)); ?>"><?php echo e($value->sub_category_name); ?></a>
            </div>
            <h3 class="product-title"><a href="<?php echo e(route('front.category', $value->slug)); ?>"><?php echo e($value->title); ?></a></h3>
            <div class="product-price">
              <?php echo number_format((float)($value->price), 0, '.', ',') . ' VND'; ?>
            </div>
            <div class="ratings-container">
              <div class="ratings">
                <div class="ratings-val" style="width: <?php echo e($value->getReviewRating($value->id)); ?>%;"></div>
              </div>
              <span class="ratings-text">( <?php echo e($value->getTotalReview()); ?> đánh giá )</span>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/product/_list.blade.php ENDPATH**/ ?>