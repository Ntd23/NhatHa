<aside class="col-md-3 col-lg-2">
  <ul class="nav nav-dashboard flex-column mb-3 mb-md-0" role="tablist">
    <li class="nav-item">
      <a class="nav-link <?php if(Request::segment(2) == 'dashboard'): ?> active <?php endif; ?>" href="<?php echo e(route('front.dashboard')); ?>">Bảng điều
        khiển</a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php if(Request::segment(2) == 'order'): ?> active <?php endif; ?>"  href="<?php echo e(route('front.order')); ?>">Theo dõi đơn hàng</a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php if(Request::segment(2) == 'edit-profile'): ?> active <?php endif; ?>" href="<?php echo e(route('front.edit_profile')); ?>">Hồ sơ</a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php if(Request::segment(2) == 'change-password'): ?> active <?php endif; ?>" href="<?php echo e(route('front.change_password')); ?>">Đổi mật khẩu</a>
    </li>
    <li class="nav-item">
		<?php
			$getUnreadNotificationCount= App\Models\Notification::getUnreadNotificationCount(Auth::user()->id);
		?>
      <a class="nav-link <?php if(Request::segment(2) == 'notifications'): ?> active <?php endif; ?>" href="<?php echo e(route('front.notifications')); ?>">
			Thông báo <strong>(<?php echo e($getUnreadNotificationCount); ?>)</strong>
			</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('logout')); ?>">Đăng xuất</a>
    </li>
  </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/user/_sidebar.blade.php ENDPATH**/ ?>