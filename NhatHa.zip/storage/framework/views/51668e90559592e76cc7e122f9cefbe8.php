<?php $__env->startSection('content'); ?>
  <div class="page-wrapper">
    <div class="content">
      <div class="row">
        <div class="col-12">
          <h4 class="page-title">Liên hệ</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <?php echo $__env->make('admin.layout.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <form method="get">
            <?php echo e(csrf_field()); ?>

            <div class="card-box row">
              <div class="form-group col-2">
                <label class="col-form-label">ID</label>
                <input class="form-control" type="text" name="id" value="<?php echo e(Request::get('id')); ?>">
              </div>
              <div class="form-group col-2">
                <label class="col-form-label">Tên</label>
                <input class="form-control" type="text" name="name" value="<?php echo e(Request::get('name')); ?>">
              </div>
              <div class="form-group col-2">
                <label class="col-form-label">Điện thoại</label>
                <input class="form-control" type="text" name="phone" value="<?php echo e(Request::get('phone')); ?>">
              </div>
              <div class="form-group col-2">
                <label class="col-form-label">Email</label>
                <input class="form-control" type="text" name="email" value="<?php echo e(Request::get('email')); ?>">
              </div>
              <div class="form-group col-2">
                <label class="col-form-label">Chủ đề</label>
                <input class="form-control" type="text" name="subject" value="<?php echo e(Request::get('subject')); ?>">
              </div>
              <div class="form-group col-6">
                <div class="row"><button class="btn btn-primary ml-3">Tìm kiếm</button>
                  <a href="<?php echo e(route('admin.contact')); ?>" class="btn btn-dark mx-3">Làm mới</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      <?php echo $__env->make('admin.layout.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <table class="table table-striped custom-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Khách hàng</th>
                  <th>Tên đăng nhập</th>
                  <th>Điện thoại</th>
                  <th>Email</th>
                  <th>Chủ đề</th>
                  <th>Nội dung</th>
                  <th>Ngày gửi</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $getRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($value->id); ?></td>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e(!empty($value->getUser) ? $value->getUser->name : ''); ?></td>
                    <td><?php echo e($value->phone); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->subject); ?></td>
                    <td><?php echo e(substr($value->message, 0, 30)); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($value->created_at))); ?></td>
                    <td>
                      <a href="<?php echo e(route('admin.delete_contact', $value->id)); ?>"
                        onclick="return confirm('Bạn muốn xóa tin nhắn này?')"><i class="fa fa-trash-o m-r-5"></i>Xóa</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div style="padding: 10px; float: right;">
              <?php echo $getRecord->appends(Illuminate\Support\Facades\Request::except('pages'))->links(); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>