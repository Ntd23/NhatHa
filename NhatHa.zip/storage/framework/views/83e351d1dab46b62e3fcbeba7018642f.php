<?php $__env->startSection('content'); ?>
  <div class="page-wrapper">
    <div class="content">
      <div class="row">
        <div class="col-sm-12">
          <h4 class="page-title"><?php echo e($header_title); ?></h4>
        </div>
      </div>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
			<?php echo $__env->make('admin.layout.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="row">
        <div class="col-lg-12">
          <form action="<?php echo e(route('admin.update_payment_setting')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="card-box">
              <h4 class="card-title">Phương thức thanh toán</h4>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Thanh toán khi nhận hàng</label>
                <div class="col-md-9">
                  <input type="checkbox" name="is_cash_delivery"
                    <?php echo e(!empty($getRecord->is_cash_delivery) ? 'checked' : ''); ?>>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Stripe</label>
                <div class="col-md-9">
                  <input type="checkbox" name="is_stripe" <?php echo e(!empty($getRecord->is_stripe) ? 'checked' : ''); ?>>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Stripe Public Key</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="stripe_public_key"
                    value="<?php echo e(old('stripe_public_key', !empty($getRecord->stripe_public_key) ? $getRecord->stripe_public_key : '')); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">Stripe Secret Key</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="stripe_secret_key"
                    value="<?php echo e(old('stripe_secret_key', !empty($getRecord->stripe_secret_key) ? $getRecord->stripe_secret_key : '')); ?>"">
                </div>
              </div>
							<div class="form-group row">
                <label class="col-form-label col-md-3">MoMo Partner Code</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="momo_partner_code"
                    value="<?php echo e(old('momo_partner_code', !empty($getRecord->momo_partner_code) ? $getRecord->momo_partner_code : '')); ?>"">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">MoMo Access Key</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="momo_access_key"
                    value="<?php echo e(old('momo_access_key', !empty($getRecord->momo_access_key) ? $getRecord->momo_access_key : '')); ?>"">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-form-label col-md-3">MoMo Secret Key</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="momo_secret_key"
                    value="<?php echo e(old('momo_secret_key', !empty($getRecord->momo_secret_key) ? $getRecord->momo_secret_key : '')); ?>"">
                </div>
              </div>
            </div>
            <div class="m-t-20 text-center">
              <button class="btn btn-primary submit-btn">Cập nhật</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NhatHa\resources\views/admin/setting/payment_setting.blade.php ENDPATH**/ ?>